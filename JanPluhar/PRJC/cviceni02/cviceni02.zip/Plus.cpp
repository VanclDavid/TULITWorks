#include "Plus.h"
int plus(int a, int b) {
	return (a + b);
}
#pragma once
void counter(int *sum_counter, int *minus_counter,int operation);